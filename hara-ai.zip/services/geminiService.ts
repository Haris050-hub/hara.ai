import { GoogleGenAI, Chat, GenerateContentResponse, Content } from "@google/genai";
import { Message } from "../types";

// Dynamic System instruction to enforce the "Hara AI" persona with real-time awareness
const getSystemInstruction = () => {
  const now = new Date();
  const dateString = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const timeString = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  return `
You are **Hara AI 1.0**.
Your name is Hara AI. You are a highly advanced, helpful, and sleek AI assistant.
Current Date and Time: ${dateString}, ${timeString}.

CRITICAL RULES:
1. **IDENTITY**: If asked "Who are you?", "Your model?", "Version?", answer: "I am Hara AI 1.0." Do NOT mention Gemini, Google, or Alphabet.
2. **NO FAKE FILES**: You **cannot** generate files, download links, or images directly.
   - NEVER output a response like "image.txt" or "cat.png".
   - NEVER output ASCII art unless specifically asked for "ASCII art".
   - If the user asks for an image (e.g., "cat image") and you receive this request (meaning the system failed to intercept it), you **MUST** apologize and say: "I am a text model. To generate an image, please try phrasing it like 'Generate an image of a cat'."
3. **TONE**: Professional, futuristic, efficient. Color theme: Emerald Green.
4. **FORMATTING**: Use clean Markdown. Keep responses concise.
`;
};

// Helper to get API Key (User provided or Environment)
const getApiKey = () => {
  return localStorage.getItem('hara_api_key') || process.env.API_KEY;
};

// Check if the key is likely an OpenRouter key
const isOpenRouterKey = (key: string) => {
  return key.startsWith('sk-or-');
};

let chatInstance: Chat | null = null;
let aiInstance: GoogleGenAI | null = null;
let activeKey: string | null = null;

// --- GEMINI (GOOGLE) IMPLEMENTATION ---
const getGeminiAi = (key: string) => {
  if (!aiInstance || activeKey !== key) {
    aiInstance = new GoogleGenAI({ apiKey: key });
    activeKey = key;
    chatInstance = null;
  }
  return aiInstance;
};

const initializeGeminiChat = (key: string, historyMessages: Message[]): Chat => {
  const ai = getGeminiAi(key);
  
  const history: Content[] = historyMessages.map(msg => {
    const parts: any[] = [{ text: msg.content }];
    if (msg.image && msg.image.startsWith('data:')) {
      const [header, data] = msg.image.split(',');
      const mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
      parts.push({ inlineData: { mimeType, data } });
    }
    return { role: msg.role, parts };
  });

  // Using Flash Lite 2.0 as it is currently the most stable free tier model
  chatInstance = ai.chats.create({
    model: 'gemini-2.0-flash-lite-preview-02-05', 
    config: { systemInstruction: getSystemInstruction(), temperature: 0.7 },
    history: history
  });
  return chatInstance;
};

// --- OPENROUTER IMPLEMENTATION ---

const OPENROUTER_MODELS = [
  "google/gemini-2.0-flash-lite-preview-02-05:free", // Current Best Free
  "google/gemini-2.0-pro-exp-02-05:free",            // High Quality
  "openrouter/auto",                                  // Auto-routing
  "deepseek/deepseek-r1:free",                        // Reliable alternative
  "deepseek/deepseek-r1-distill-llama-70b:free",      // Fast alternative
  "meta-llama/llama-3.3-70b-instruct:free",           // Meta's best free
  "nvidia/llama-3.1-nemotron-70b-instruct:free",      // Good instruction following
  "google/gemini-2.0-flash-thinking-exp:free",        // Reasoning
  "google/gemini-exp-1206:free"                       // Older Stable Google
];

const streamOpenRouter = async (
  key: string,
  historyMessages: Message[],
  newMessage: string,
  newImage: string | null,
  onChunk: (text: string) => void
) => {
  const messages = [
    { role: 'system', content: getSystemInstruction() },
    ...historyMessages.map(msg => {
       const content: any[] = [{ type: 'text', text: msg.content }];
       if (msg.image) {
          content.push({ type: 'image_url', image_url: { url: msg.image } });
       }
       return { role: msg.role, content };
    }),
    { 
      role: 'user', 
      content: newImage 
        ? [{ type: 'text', text: newMessage }, { type: 'image_url', image_url: { url: newImage } }] 
        : newMessage 
    }
  ];

  let lastError = null;

  for (const model of OPENROUTER_MODELS) {
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${key}`,
          "Content-Type": "application/json",
          "HTTP-Referer": window.location.origin,
          "X-Title": "Hara AI"
        },
        body: JSON.stringify({
          model: model,
          messages: messages,
          stream: true
        })
      });

      if (!response.ok) {
         const err = await response.json();
         const errMsg = err.error?.message || `Error ${response.status}`;
         console.warn(`OpenRouter model ${model} failed: ${errMsg}`);
         throw new Error(errMsg);
      }

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let buffer = "";
      let fullText = "";
      let hasReceivedContent = false;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (line.trim() === "") continue;
          if (line.trim() === "data: [DONE]") continue;
          if (line.startsWith("data: ")) {
            try {
              const json = JSON.parse(line.slice(6));
              if (json.error) {
                  throw new Error(json.error.message || "Stream Error");
              }
              const content = json.choices[0]?.delta?.content || "";
              if (content) {
                fullText += content;
                onChunk(fullText);
                hasReceivedContent = true;
              }
            } catch (e) {
              if ((e as Error).message !== "Stream Error") {
                 // ignore
              } else {
                  throw e;
              }
            }
          }
        }
      }
      return fullText; 
    } catch (e) {
      lastError = e;
      continue;
    }
  }
  throw lastError || new Error("All OpenRouter models are currently unavailable.");
};


export const initializeChat = (historyMessages: Message[] = []): void => {
  const key = getApiKey();
  if (key && !isOpenRouterKey(key)) {
    initializeGeminiChat(key, historyMessages);
  }
};


export const sendMessageStream = async (
  text: string, 
  imageBase64: string | null,
  history: Message[],
  onChunk: (text: string) => void
): Promise<string> => {
  const key = getApiKey();
  if (!key) throw new Error("API Key missing. Please login again.");

  if (isOpenRouterKey(key)) {
    return streamOpenRouter(key, history, text, imageBase64, onChunk);
  }

  // Gemini Path
  chatInstance = initializeGeminiChat(key, history);

  try {
    const parts: any[] = [{ text: text }];
    if (imageBase64) {
      const [header, data] = imageBase64.split(',');
      const mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
      parts.push({ inlineData: { mimeType, data } });
    }

    const result = await chatInstance.sendMessageStream({ message: parts });
    let fullText = "";
    for await (const chunk of result) {
      const c = chunk as GenerateContentResponse;
      if (c.text) {
        fullText += c.text;
        onChunk(fullText);
      }
    }
    return fullText;
  } catch (error: any) {
    const msg = error?.message || '';
    if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) {
        throw new Error("Gemini Quota Exceeded. The free tier is busy. Please try again in a moment or add your own API Key in Settings.");
    }
    throw error;
  }
};

export const generateImage = async (prompt: string): Promise<string> => {
  const seed = Math.floor(Math.random() * 1000000);
  const encoded = encodeURIComponent(prompt);
  const imageUrl = `https://image.pollinations.ai/prompt/${encoded}?nologo=true&private=true&enhanced=true&model=flux&seed=${seed}`;
  return Promise.resolve(imageUrl);
};